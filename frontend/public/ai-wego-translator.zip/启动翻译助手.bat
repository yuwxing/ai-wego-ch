@echo off
chcp 65001 >nul
cd /d "%~dp0"
python -m pip install keyboard -q 2>nul
start /min "" pythonw translator_server.py
timeout /t 2 >nul
start http://127.0.0.1:18789
exit
