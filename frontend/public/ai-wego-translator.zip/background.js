chrome.runtime.onInstalled.addListener(() => {
  console.log('AI-Wego Translate 已安装');
});

chrome.commands.onCommand.addListener((command) => {
  if (command === 'translate-input') {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {action: 'translate'}).catch(() => {});
      }
    });
  }
});
