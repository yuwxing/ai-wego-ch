# -*- coding: utf-8 -*-
import sys, os, json, time, ctypes, ctypes.wintypes, urllib.request, webbrowser, threading
from http.server import HTTPServer, BaseHTTPRequestHandler

DIR = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.join(DIR, 'config.json')

def load_cfg():
    c = {'api_key': ''}
    if os.path.exists(CFG):
        try:
            with open(CFG, 'r', encoding='utf-8') as f:
                c.update(json.load(f))
        except: pass
    return c

def save_cfg(c):
    with open(CFG, 'w', encoding='utf-8') as f:
        json.dump(c, f, ensure_ascii=False, indent=2)

config = load_cfg()
PORT = 18789

CF_UNICODETEXT, GMEM_MOVABLE = 13, 2

def get_clip():
    if not ctypes.windll.user32.OpenClipboard(None): return ''
    try:
        h = ctypes.windll.user32.GetClipboardData(CF_UNICODETEXT)
        if not h: return ''
        p = ctypes.windll.kernel32.GlobalLock(h)
        if not p: return ''
        try: return ctypes.wstring_at(p)
        finally: ctypes.windll.kernel32.GlobalUnlock(h)
    finally: ctypes.windll.user32.CloseClipboard()

def set_clip(text):
    if not ctypes.windll.user32.OpenClipboard(None): return False
    try:
        ctypes.windll.user32.EmptyClipboard()
        buf = (text + '\0').encode('utf-16-le')
        h = ctypes.windll.kernel32.GlobalAlloc(GMEM_MOVABLE, len(buf))
        if not h: return False
        p = ctypes.windll.kernel32.GlobalLock(h)
        if p: ctypes.memmove(p, buf, len(buf)); ctypes.windll.kernel32.GlobalUnlock(h)
        ctypes.windll.user32.SetClipboardData(CF_UNICODETEXT, h)
        return True
    finally: ctypes.windll.user32.CloseClipboard()

def do_translate(text, api_key):
    if not text.strip(): return ''
    has_cn = any('\u4e00' <= c <= '\u9fff' for c in text)
    target = 'en' if has_cn else 'zh'
    body = json.dumps({
        'model': 'deepseek-chat',
        'messages': [
            {'role': 'system', 'content': f'翻译助手：将{"中文" if target=="en" else "英文"}翻译成{"英文" if target=="en" else "中文"}，只返回结果不要解释。'},
            {'role': 'user', 'content': text}
        ],
        'max_tokens': 2048, 'temperature': 0.3,
    }).encode('utf-8')
    req = urllib.request.Request('https://api.deepseek.com/v1/chat/completions', data=body,
        headers={'Content-Type': 'application/json', 'Authorization': f'Bearer {api_key}'})
    resp = urllib.request.urlopen(req, timeout=30)
    return json.loads(resp.read().decode('utf-8'))['choices'][0]['message']['content'].strip().strip('"\'')

# ── HTML 页面 ──
HTML = r'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AI-Wego 翻译</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap');
body{font-family:'Noto Sans SC','Microsoft YaHei UI',sans-serif;background:linear-gradient(135deg,#e6faf7 0%,#f0fdfa 40%,#ffffff 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;margin:0}
.card{background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-radius:24px;box-shadow:0 8px 40px rgba(20,230,201,0.15),0 2px 8px rgba(0,0,0,0.04);padding:36px 40px;width:560px;max-width:100%;border:1px solid rgba(20,230,201,0.2);transition:box-shadow 0.3s}
.card:hover{box-shadow:0 12px 48px rgba(20,230,201,0.2),0 2px 8px rgba(0,0,0,0.04)}
.header{display:flex;align-items:center;gap:10px;margin-bottom:28px}
.header-icon{width:36px;height:36px;background:linear-gradient(135deg,#14E6C9,#00BFA5);border-radius:10px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px}
.header-text{font-size:20px;font-weight:600;background:linear-gradient(135deg,#0d9488,#14E6C9);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.header-badge{font-size:11px;background:#e6faf7;color:#0d9488;padding:2px 10px;border-radius:20px;margin-left:6px}
.label{font-size:13px;font-weight:500;color:#5c7a73;margin-bottom:6px;display:flex;align-items:center;gap:6px}
.input-wrap{position:relative;margin-bottom:16px}
.input-wrap textarea{width:100%;padding:14px 16px;border:2px solid #e2e8f0;border-radius:16px;font-size:15px;font-family:inherit;outline:none;resize:none;height:90px;transition:all 0.25s;background:#fff;color:#1a2e2a}.input-wrap textarea:focus{border-color:#14E6C9;box-shadow:0 0 0 4px rgba(20,230,201,0.12)}
.buttons{display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap}
.btn{display:flex;align-items:center;gap:6px;padding:10px 28px;border:none;border-radius:14px;font-size:14px;font-weight:500;font-family:inherit;cursor:pointer;transition:all 0.25s;outline:none}
.btn-primary{background:linear-gradient(135deg,#14E6C9,#00BFA5);color:#fff;box-shadow:0 4px 14px rgba(20,230,201,0.3)}.btn-primary:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(20,230,201,0.4)}.btn-primary:active{transform:translateY(0)}
.btn-secondary{background:#e6faf7;color:#0d9488;box-shadow:0 2px 8px rgba(0,0,0,0.04)}.btn-secondary:hover{background:#b2f5ed;transform:translateY(-2px)}.btn-secondary:active{transform:translateY(0)}
.btn-icon{background:transparent;border:none;font-size:20px;cursor:pointer;padding:6px 10px;border-radius:10px;color:#5c7a73;transition:all 0.2s;margin-left:auto}.btn-icon:hover{background:#e6faf7;color:#0d9488}
.divider{height:2px;background:linear-gradient(90deg,transparent,#14E6C9,transparent);opacity:0.3;margin-bottom:16px}
.output-wrap{position:relative}
.output-wrap textarea{width:100%;padding:14px 16px;border:2px solid #e2e8f0;border-radius:16px;font-size:15px;font-family:inherit;outline:none;resize:none;height:120px;transition:all 0.25s;background:#fff;color:#1a2e2a}.output-wrap textarea:focus{border-color:#14E6C9;box-shadow:0 0 0 4px rgba(20,230,201,0.12)}
.status{display:flex;align-items:center;gap:8px;margin-top:14px;font-size:13px;color:#5c7a73;padding:8px 14px;background:#e6faf7;border-radius:10px;transition:all 0.3s;min-height:38px}
.status.success{color:#0d9488;background:#e6faf7}
.status.error{color:#dc2626;background:#fee2e2}
.status.key-missing{color:#d97706;background:#fef3c7}
.hotkey-hint{font-size:12px;color:#94a3b8;margin-top:12px;text-align:center;border-top:1px solid #f1f5f9;padding-top:12px}
.hotkey-hint kbd{background:#f1f5f9;padding:2px 8px;border-radius:6px;font-size:11px;border:1px solid #e2e8f0;font-family:inherit}
.settings-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.3);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);align-items:center;justify-content:center;z-index:100}
.settings-overlay.active{display:flex}
.settings-panel{background:#fff;border-radius:20px;padding:28px 32px;width:400px;max-width:90vw;box-shadow:0 20px 60px rgba(0,0,0,0.15);animation:slideUp 0.3s ease}
@keyframes slideUp{from{transform:translateY(20px);opacity:0}to{transform:translateY(0);opacity:1}}
.settings-title{font-size:16px;font-weight:700;color:#1a2e2a;margin-bottom:18px;display:flex;align-items:center;gap:8px}
.settings-close{background:transparent;border:none;font-size:20px;cursor:pointer;color:#5c7a73;margin-left:auto;padding:4px 8px;border-radius:8px;transition:all 0.2s}.settings-close:hover{background:#e6faf7}
.settings-label{font-size:13px;font-weight:500;color:#5c7a73;margin-bottom:6px}
.settings-input{width:100%;padding:10px 14px;border:2px solid #e2e8f0;border-radius:12px;font-size:14px;font-family:inherit;outline:none;transition:all 0.25s;background:#f8fafc;color:#1a2e2a;margin-bottom:16px}.settings-input:focus{border-color:#14E6C9;box-shadow:0 0 0 4px rgba(20,230,201,0.1)}
.settings-save{float:right;padding:8px 28px;border:none;border-radius:12px;font-size:14px;font-weight:500;font-family:inherit;cursor:pointer;background:linear-gradient(135deg,#14E6C9,#00BFA5);color:#fff;box-shadow:0 4px 14px rgba(20,230,201,0.3);transition:all 0.25s}.settings-save:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(20,230,201,0.4)}
</style>
</head>
<body>
<div class="card">
  <div class="header">
    <div class="header-icon">🍃</div>
    <div class="header-text">AI-Wego 翻译</div>
    <span class="header-badge">全局</span>
  </div>

  <div class="label">✏️ 输入文本</div>
  <div class="input-wrap">
    <textarea id="inputText" placeholder="输入或粘贴要翻译的内容..."></textarea>
  </div>

  <div class="buttons">
    <button class="btn btn-primary" onclick="translateText()">🍃 翻译</button>
    <button class="btn btn-secondary" onclick="translateClipboard()">📋 剪贴板</button>
    <button class="btn-icon" onclick="openSettings()">⚙</button>
  </div>

  <div class="divider"></div>

  <div class="label">📝 翻译结果</div>
  <div class="output-wrap">
    <textarea id="outputText" placeholder="翻译结果会显示在这里..." readonly></textarea>
  </div>

  <div class="status" id="status">💡 输入文本后点击「翻译」或按 Enter</div>
  <div class="hotkey-hint">全局快捷键 <kbd>Ctrl</kbd> + <kbd>Alt</kbd> + <kbd>T</kbd> — 在任何软件中选中文本后快速翻译</div>
</div>

<div class="settings-overlay" id="settingsOverlay">
  <div class="settings-panel">
    <div class="settings-title">⚙ 设置 <button class="settings-close" onclick="closeSettings()">×</button></div>
    <div class="settings-label">DeepSeek API Key</div>
    <input class="settings-input" id="apiKeyInput" type="password" placeholder="sk-..." />
    <button class="settings-save" onclick="saveSettings()">保存</button>
  </div>
</div>

<script>
let apiKey = '';

async function api(path, data) {
  const res = await fetch(path, {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  });
  return res.json();
}

function setStatus(msg, type) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = 'status' + (type ? ' ' + type : '');
}

document.getElementById('inputText').addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); translateText(); }
});

async function translateText() {
  const text = document.getElementById('inputText').value.trim();
  if (!text) return;
  if (!apiKey) { setStatus('⚠ 请先点击 ⚙ 配置 API Key', 'key-missing'); return; }
  setStatus('🍃 翻译中...', '');
  try {
    const res = await api('/api/translate', {text, apiKey, target: /[\u4e00-\u9fa5]/.test(text) ? 'en' : 'zh'});
    if (res.error) { setStatus('❌ ' + res.error, 'error'); return; }
    document.getElementById('outputText').value = res.result;
    setStatus('✅ 已复制到剪贴板', 'success');
  } catch(e) { setStatus('❌ ' + e.message, 'error'); }
}

async function translateClipboard() {
  const res = await api('/api/clipboard', {});
  if (res.text) {
    document.getElementById('inputText').value = res.text;
    translateText();
  }
}

async function openSettings() {
  const res = await api('/api/get-key', {});
  if (res.key) document.getElementById('apiKeyInput').value = res.key;
  document.getElementById('settingsOverlay').classList.add('active');
}

function closeSettings() {
  document.getElementById('settingsOverlay').classList.remove('active');
}

async function saveSettings() {
  const key = document.getElementById('apiKeyInput').value.trim();
  await api('/api/set-key', {key});
  apiKey = key;
  setStatus('✅ 配置已保存', 'success');
  closeSettings();
}

async function init() {
  const res = await api('/api/get-key', {});
  if (res.key) apiKey = res.key;
  if (!apiKey) setStatus('⚠ 点击 ⚙ 配置 DeepSeek API Key', 'key-missing');
}
init();
</script>
</body>
</html>'''

# ── HTTP 服务 ──
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(HTML.encode('utf-8'))
        else:
            self.send_response(404); self.end_headers()

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers['Content-Length'])).decode('utf-8'))
        res = {'ok': True}
        if self.path == '/api/translate':
            text, key = body.get('text', ''), body.get('apiKey', '')
            try:
                res['result'] = do_translate(text, key)
                set_clip(res['result'])
            except Exception as e:
                res = {'error': str(e)}
        elif self.path == '/api/clipboard':
            res['text'] = get_clip()
        elif self.path == '/api/get-key':
            res['key'] = config.get('api_key', '')
        elif self.path == '/api/set-key':
            config['api_key'] = body.get('key', '')
            save_cfg(config)
        else:
            res = {'error': 'not found'}
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(res, ensure_ascii=False).encode('utf-8'))

    def log_message(self, *a): pass

def start_server():
    s = HTTPServer(('127.0.0.1', PORT), Handler)
    s.serve_forever()

def hotkey_listener():
    try:
        import keyboard
        def do_trans():
            text = get_clip()
            if not text or not config.get('api_key'): return
            try:
                result = do_translate(text, config['api_key'])
                set_clip(result)
            except:
                pass
        keyboard.add_hotkey('ctrl+alt+t', do_trans)
        keyboard.wait()
    except ImportError:
        pass

def create_tray():
    try:
        from PIL import Image, ImageDraw, ImageFont
        import pystray

        img = Image.new('RGBA', (64, 64), (0,0,0,0))
        draw = ImageDraw.Draw(img)
        draw.ellipse([2,2,62,62], fill=(16,185,129,255))
        draw.ellipse([10,10,54,54], fill=(20,230,201,255))
        draw.text((18,18), '译', fill=(255,255,255))

        def on_translate(icon, item):
            text = get_clip()
            if text and config.get('api_key'):
                try:
                    r = do_translate(text, config['api_key'])
                    set_clip(r)
                except: pass

        def on_open(icon, item):
            webbrowser.open(f'http://127.0.0.1:{PORT}')

        def on_quit(icon, item):
            icon.stop()
            os._exit(0)

        menu = pystray.Menu(
            pystray.MenuItem('🍃 打开翻译', on_open),
            pystray.MenuItem('⌨ 翻译剪贴板', on_translate),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem('退出', on_quit),
        )
        icon = pystray.Icon('awego_translator', img, 'AI-Wego 翻译 (Ctrl+Alt+T)', menu)
        icon.run()
    except ImportError:
        try:
            import tkinter as tk
            root = tk.Tk()
            root.title('AI-Wego 翻译')
            root.geometry('1x1+0+0')
            root.resizable(False, False)
            root.configure(bg='#10b981')
            root.attributes('-alpha', 0.01)
            root.attributes('-topmost', True)

            bar = tk.Frame(root, bg='#10b981', height=1)
            bar.pack(fill='x')
            tk.Label(root, text='🍃 AI-Wego 翻译 (Ctrl+Alt+T)\n后台运行中，选中文本后按快捷键',
                     bg='#10b981', fg='white', font=('Microsoft YaHei UI', 10)).pack(padx=20, pady=10)

            root.protocol('WM_DELETE_WINDOW', lambda: (root.withdraw(), None))

            def show_window():
                root.deiconify()
                root.geometry('280x60+{}+{}'.format(root.winfo_screenwidth()-320, 80))
                root.after(3000, root.withdraw)

            import keyboard
            keyboard.add_hotkey('ctrl+alt+t', lambda: (
                set_clip(do_translate(get_clip(), config.get('api_key', '')) or get_clip())
            ) if config.get('api_key') else None)

            root.after(100, show_window)
            root.mainloop()
        except:
            input('按 Enter 退出')

if __name__ == '__main__':
    try:
        lock_f = os.path.join(DIR, '.lock')
        f = open(lock_f, 'w')
        import msvcrt
        msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
    except:
        webbrowser.open(f'http://127.0.0.1:{PORT}')
        sys.exit(0)

    threading.Thread(target=start_server, daemon=True).start()
    threading.Thread(target=hotkey_listener, daemon=True).start()
    webbrowser.open(f'http://127.0.0.1:{PORT}')

    create_tray()
