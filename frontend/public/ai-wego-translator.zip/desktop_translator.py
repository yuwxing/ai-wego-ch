# -*- coding: utf-8 -*-
import sys, os, json, time, ctypes, ctypes.wintypes, urllib.request
import tkinter as tk

DIR = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.join(DIR, 'config.json')

def load_cfg():
    c = {'api_key': ''}
    if os.path.exists(CFG):
        try:
            with open(CFG, 'r', encoding='utf-8') as f:
                c.update(json.load(f))
        except: pass
    return c

def save_cfg(c):
    with open(CFG, 'w', encoding='utf-8') as f:
        json.dump(c, f, ensure_ascii=False, indent=2)

config = load_cfg()
CF_UNICODETEXT, GMEM_MOVABLE = 13, 2

def get_clip():
    if not ctypes.windll.user32.OpenClipboard(None): return ''
    try:
        h = ctypes.windll.user32.GetClipboardData(CF_UNICODETEXT)
        if not h: return ''
        p = ctypes.windll.kernel32.GlobalLock(h)
        if not p: return ''
        try: return ctypes.wstring_at(p)
        finally: ctypes.windll.kernel32.GlobalUnlock(h)
    finally: ctypes.windll.user32.CloseClipboard()

def set_clip(text):
    if not ctypes.windll.user32.OpenClipboard(None): return False
    try:
        ctypes.windll.user32.EmptyClipboard()
        buf = (text + '\0').encode('utf-16-le')
        h = ctypes.windll.kernel32.GlobalAlloc(GMEM_MOVABLE, len(buf))
        if not h: return False
        p = ctypes.windll.kernel32.GlobalLock(h)
        if p: ctypes.memmove(p, buf, len(buf)); ctypes.windll.kernel32.GlobalUnlock(h)
        ctypes.windll.user32.SetClipboardData(CF_UNICODETEXT, h)
        return True
    finally: ctypes.windll.user32.CloseClipboard()

def do_translate(text, api_key):
    if not text.strip(): return ''
    has_cn = any('\u4e00' <= c <= '\u9fff' for c in text)
    target = 'en' if has_cn else 'zh'
    body = json.dumps({
        'model': 'deepseek-chat',
        'messages': [
            {'role': 'system', 'content': f'翻译助手：将{"中文" if target=="en" else "英文"}翻译成{"英文" if target=="en" else "中文"}，只返回结果不要解释。'},
            {'role': 'user', 'content': text}
        ],
        'max_tokens': 2048, 'temperature': 0.3,
    }).encode('utf-8')
    req = urllib.request.Request('https://api.deepseek.com/v1/chat/completions', data=body,
        headers={'Content-Type': 'application/json', 'Authorization': f'Bearer {api_key}'})
    resp = urllib.request.urlopen(req, timeout=30)
    return json.loads(resp.read().decode('utf-8'))['choices'][0]['message']['content'].strip().strip('"\'')

# ── 配色 ──
TEAL = '#14E6C9'
TEAL_DEEP = '#00BFA5'
TEAL_DARK = '#00897B'
TEAL_LIGHT = '#B2F5ED'
BG_TOP = '#ffffff'
BG_BOT = '#e6faf7'
TEXT_C = '#1a2e2a'
TEXT_MUTED = '#5c7a73'
FONT_NAME = 'Microsoft YaHei UI'
TEXT_C = '#1a2e2a'
TEXT_MUTED = '#5c7a73'

def make_btn(parent, text, cmd, bg=TEAL, fg='white', font_size=11, bold=True, px=24, py=8):
    w = 'bold' if bold else 'normal'
    b = tk.Label(parent, text=text, bg=bg, fg=fg,
                 font=(FONT_NAME, font_size, w),
                 padx=px, pady=py, cursor='hand2')
    b.bind('<Button-1>', lambda e: cmd())
    b.bind('<Enter>', lambda e: b.config(bg=TEAL_DEEP))
    b.bind('<Leave>', lambda e: b.config(bg=bg))
    return b

class App:
    def __init__(self):
        self.win = tk.Tk()
        self.win.title('')
        self.win.geometry('540x460')
        self.win.resizable(False, False)
        self.win.configure(bg=BG_TOP)
        self.win.attributes('-topmost', True)
        self.win.overrideredirect(True)

        # 检测系统字体
        global FONT_NAME
        for fn in ['Noto Sans CJK SC', 'Source Han Sans SC', '思源黑体', 'Microsoft YaHei UI']:
            try:
                f = tk.font.Font(family=fn, size=10)
                if f.measure('测试') > 0:
                    FONT_NAME = fn
                    break
            except: pass

        self._x = self._y = 0
        self.win.bind('<Button-1>', self._start_move)
        self.win.bind('<B1-Motion>', self._do_move)

        # ── 背景 ──
        bg_frame = tk.Frame(self.win, bg='#e6faf7')
        bg_frame.pack(fill='both', expand=True)

        # ── 标题 ──
        bar = tk.Frame(bg_frame, bg=TEAL, height=38)
        bar.pack(fill='x', pady=(0, 0))
        bar.bind('<Button-1>', self._start_move)
        bar.bind('<B1-Motion>', self._do_move)

        tk.Label(bar, text='🍃  AI-Wego 翻译', bg=TEAL, fg='white',
                 font=(FONT_NAME, 13, 'bold')).pack(side='left', padx=18, pady=6)
        for ch, cb in [('🗕', lambda: self.win.iconify()), ('🗙', self.quit)]:
            lb = tk.Label(bar, text=ch, bg=TEAL, fg='white',
                          font=('Segoe UI', 14), cursor='hand2', padx=8)
            lb.pack(side='right')
            lb.bind('<Button-1>', lambda e, c=cb: c())

        # ── 主体 ──
        body = tk.Frame(bg_frame, bg='#e6faf7')
        body.pack(fill='both', expand=True, padx=24, pady=(18, 16))

        # 输入
        tk.Label(body, text='输入文本', bg='#e6faf7', fg=TEXT_MUTED,
                 font=(FONT_NAME, 10)).pack(anchor='w')
        inp_box = tk.Frame(body, bg=TEAL_LIGHT, pady=2, padx=2)
        inp_box.pack(fill='x', pady=(6, 14))
        self.input_txt = tk.Text(inp_box, height=3, relief='flat', bd=0,
                                 wrap='word', padx=14, pady=10,
                                 font=(FONT_NAME, 12),
                                 bg='white', fg=TEXT_C, insertbackground=TEAL_DEEP)
        self.input_txt.pack(fill='x')
        self.input_txt.bind('<Return>', self.on_enter)
        self.input_txt.bind('<Shift-Return>', lambda e: self.input_txt.insert('insert', '\n'))

        # 按钮行
        bf = tk.Frame(body, bg='#e6faf7')
        bf.pack(fill='x', pady=(0, 16))

        for info in [
            ('  🍃  翻译  ', TEAL, 'white', self.translate),
            ('  📋  剪贴板  ', TEAL_LIGHT, TEAL_DARK, self.translate_clipboard),
        ]:
            shadow = tk.Frame(bf, bg=TEAL_DEEP if info[1] == TEAL else TEAL_LIGHT, padx=0, pady=2)
            shadow.pack(side='left', padx=(0, 10))
            btn = tk.Label(shadow, text=info[0], bg=info[1], fg=info[2],
                           font=(FONT_NAME, 11, 'bold'), padx=26, pady=8, cursor='hand2')
            btn.pack(padx=0, pady=0)
            btn.bind('<Button-1>', lambda e, c=info[3]: c())
            btn.bind('<Enter>', lambda e, b=btn, bg=info[1]: b.config(bg=TEAL_DEEP if bg == TEAL else TEAL))
            btn.bind('<Leave>', lambda e, b=btn, bg=info[1]: b.config(bg=bg))

        tk.Label(bf, text='⚙', bg='#e6faf7', fg=TEXT_MUTED,
                 font=(FONT_NAME, 18), cursor='hand2').pack(side='right')
        bf.winfo_children()[-1].bind('<Button-1>', lambda e: self.settings())

        # 分割
        sep = tk.Frame(body, bg=TEAL_LIGHT, height=2)
        sep.pack(fill='x', pady=(0, 12))

        # 输出
        tk.Label(body, text='翻译结果', bg='#e6faf7', fg=TEXT_MUTED,
                 font=(FONT_NAME, 10)).pack(anchor='w')
        out_box = tk.Frame(body, bg=TEAL_LIGHT, pady=2, padx=2)
        out_box.pack(fill='both', expand=True, pady=(6, 0))
        self.output_txt = tk.Text(out_box, relief='flat', bd=0,
                                  wrap='word', padx=14, pady=10,
                                  font=(FONT_NAME, 12),
                                  bg='white', fg=TEXT_C)
        self.output_txt.pack(fill='both', expand=True)

        # 状态
        self.status = tk.Label(bg_frame, text='', bg=TEAL, fg='white',
                               font=(FONT_NAME, 10), anchor='w', padx=24, pady=5)
        self.status.pack(fill='x')

        if not config.get('api_key'):
            self.status.config(text='⚠  点击 ⚙ 配置 API Key', bg=TEAL_DEEP)

    def _start_move(self, e):
        self._x, self._y = e.x, e.y

    def _do_move(self, e):
        self.win.geometry(f'+{self.win.winfo_x()+e.x-self._x}+{self.win.winfo_y()+e.y-self._y}')

    def on_enter(self, e):
        self.translate(); return 'break'

    def set_status(self, msg, bg=None):
        self.status.config(text=msg, bg=bg or TEAL)
        self.win.update()

    def translate(self):
        text = self.input_txt.get('1.0', 'end-1c').strip()
        if not text: return
        if not config.get('api_key'):
            self.set_status('⚠ 点击 ⚙ 配置 API Key', TEAL_DEEP)
            return
        self.set_status('翻译中...', TEAL_DEEP)
        try:
            result = do_translate(text, config['api_key'])
        except Exception as e:
            self.set_status(f'❌ {e}', TEAL_DEEP)
            return
        self.output_txt.delete('1.0', 'end')
        self.output_txt.insert('1.0', result)
        set_clip(result)
        self.set_status('✅ 已复制到剪贴板')

    def translate_clipboard(self):
        text = get_clip()
        if text:
            self.input_txt.delete('1.0', 'end')
            self.input_txt.insert('1.0', text.strip())
            self.translate()

    def settings(self):
        sw = tk.Toplevel(self.win)
        sw.title('')
        sw.geometry('380+300+300')
        sw.resizable(False, False)
        sw.configure(bg=TEAL)
        sw.attributes('-topmost', True)
        sw.overrideredirect(True)

        inner = tk.Frame(sw, bg='white')
        inner.pack(fill='both', expand=True, padx=2, pady=2)

        bar = tk.Frame(inner, bg=TEAL, height=34)
        bar.pack(fill='x')
        tk.Label(bar, text='⚙ 设置', bg=TEAL, fg='white',
                 font=(FONT_NAME, 11, 'bold')).pack(side='left', padx=16)
        close = tk.Label(bar, text='🗙', bg=TEAL, fg='white',
                         font=('Segoe UI', 12), cursor='hand2')
        close.pack(side='right', padx=8)
        close.bind('<Button-1>', lambda e: sw.destroy())

        tk.Label(inner, text='DeepSeek API Key', bg='white', fg=TEXT_MUTED,
                 font=(FONT_NAME, 10)).pack(anchor='w', padx=20, pady=(16, 6))
        entry = tk.Entry(inner, width=50, relief='flat', bd=0, bg=TEAL_LIGHT,
                         font=(FONT_NAME, 11))
        entry.pack(fill='x', padx=20, pady=(0, 14))
        if config.get('api_key'): entry.insert(0, config['api_key'])

        def save():
            config['api_key'] = entry.get().strip()
            save_cfg(config); self.set_status('✅ 已保存'); sw.destroy()

        shadow = tk.Frame(inner, bg=TEAL_DEEP, padx=0, pady=2)
        shadow.pack(pady=(0, 14))
        save_btn = tk.Label(shadow, text='  保存  ', bg=TEAL, fg='white',
                            font=(FONT_NAME, 11, 'bold'), padx=32, pady=6, cursor='hand2')
        save_btn.pack()
        save_btn.bind('<Button-1>', lambda e: save())
        save_btn.bind('<Enter>', lambda e: save_btn.config(bg=TEAL_DEEP))
        save_btn.bind('<Leave>', lambda e: save_btn.config(bg=TEAL))

    def quit(self):
        self.win.destroy(); sys.exit(0)

    def run(self):
        self.win.mainloop()

if __name__ == '__main__':
    try:
        lf = os.path.join(DIR, '.lock')
        f = open(lf, 'w')
        import msvcrt
        msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
    except: sys.exit(0)
    App().run()
