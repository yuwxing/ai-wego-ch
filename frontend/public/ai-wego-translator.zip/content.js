(() => {
  let translateBtn = null;
  let activeInput = null;

  function isInput(el) {
    return el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT' || el.isContentEditable);
  }

  function getInputValue(el) {
    if (el.isContentEditable) return el.innerText;
    return el.value || '';
  }

  function setInputValue(el, val) {
    if (el.isContentEditable) {
      el.innerText = val;
    } else {
      el.value = val;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }

  function getApiKey() {
    return new Promise((resolve) => {
      const localKey = localStorage.getItem('deepseek_api_key') || localStorage.getItem('deepseek-api-key');
      if (localKey) {
        resolve({ key: localKey, endpoint: 'https://api.deepseek.com/v1/chat/completions' });
        return;
      }
      chrome.storage.local.get(['apiKey', 'apiEndpoint'], (result) => {
        if (result.apiKey) {
          resolve({ key: result.apiKey, endpoint: result.apiEndpoint || 'https://api.deepseek.com/v1/chat/completions' });
        } else {
          resolve(null);
        }
      });
    });
  }

  async function translateText(text, targetLang) {
    const config = await getApiKey();
    const sourceHint = targetLang === 'zh' ? '英文' : '中文';

    if (!config) {
      throw new Error('未配置 API Key。右键插件图标 → 弹出菜单 → 填写 DeepSeek API Key');
    }

    const res = await fetch(config.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.key}`,
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          { role: 'system', content: `你是一个翻译助手。请将${sourceHint}翻译成${targetLang === 'zh' ? '中文' : '英文'}，只返回翻译结果，不要解释。` },
          { role: 'user', content: text }
        ],
        max_tokens: 2048,
        temperature: 0.3,
      }),
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      throw new Error(`API 请求失败 (${res.status}): ${errText}`);
    }

    const data = await res.json();
    const reply = data.choices?.[0]?.message?.content || '';
    return reply.replace(/^["']|["']$/g, '').trim();
  }

  function positionButton(input) {
    const rect = input.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) {
      translateBtn.style.display = 'none';
      return;
    }
    translateBtn.style.display = 'flex';
    const btnX = rect.right + 6;
    const btnY = rect.top;
    const maxX = window.innerWidth - 60;
    translateBtn.style.left = Math.min(btnX, maxX) + 'px';
    translateBtn.style.top = btnY + 'px';
    translateBtn.style.height = Math.max(28, rect.height) + 'px';
  }

  function createButton() {
    if (translateBtn) return;
    translateBtn = document.createElement('button');
    translateBtn.id = '__awego_translate_btn__';
    translateBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8l6 6"/><path d="M4 14l6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="M12 20l-2.5-5.5"/><path d="M16 20l2.5-5.5"/><path d="M18.5 14.5L22 22"/><path d="M14 22h8"/></svg>`;
    translateBtn.title = 'AI 翻译 (Ctrl+Shift+E)';
    Object.assign(translateBtn.style, {
      position: 'fixed',
      zIndex: 2147483647,
      padding: '0 8px',
      fontSize: '13px',
      fontWeight: '600',
      fontFamily: 'system-ui, sans-serif',
      color: '#fff',
      background: '#10b981',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      display: 'none',
      alignItems: 'center',
      gap: '4px',
      boxShadow: '0 1px 4px rgba(0,0,0,0.25)',
      transition: 'opacity 0.15s',
      whiteSpace: 'nowrap',
      lineHeight: '1',
    });
    translateBtn.addEventListener('mouseenter', () => { translateBtn.style.opacity = '1'; });
    translateBtn.addEventListener('mouseleave', () => { translateBtn.style.opacity = '0.85'; });
    translateBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!activeInput) return;
      const text = getInputValue(activeInput);
      if (!text.trim()) return;
      const targetLang = /[\u4e00-\u9fa5]/.test(text) ? 'en' : 'zh';
      translateBtn.textContent = '翻译中...';
      translateBtn.disabled = true;
      try {
        const translated = await translateText(text, targetLang);
        setInputValue(activeInput, translated);
      } catch (err: any) {
        const msg = err?.message || '';
        translateBtn.textContent = msg.includes('API') || msg.includes('Key') ? '配置Key' : '翻译失败';
        translateBtn.title = msg || '翻译失败';
        setTimeout(() => {
          translateBtn.title = 'AI 翻译 (Ctrl+Shift+E)';
          translateBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8l6 6"/><path d="M4 14l6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="M12 20l-2.5-5.5"/><path d="M16 20l2.5-5.5"/><path d="M18.5 14.5L22 22"/><path d="M14 22h8"/></svg>`;
        }, 2000);
      }
      translateBtn.disabled = false;
    });
    document.body.appendChild(translateBtn);
  }

  function showButton(input) {
    activeInput = input;
    if (!translateBtn) createButton();
    positionButton(input);
  }

  function hideButton() {
    activeInput = null;
    if (translateBtn) translateBtn.style.display = 'none';
  }

  document.addEventListener('focusin', (e) => {
    const el = e.target;
    if (!isInput(el)) {
      if (activeInput) hideButton();
      return;
    }
    showButton(el);
  });

  document.addEventListener('focusout', (e) => {
    const el = e.relatedTarget;
    if (!el || (el.id !== '__awego_translate_btn__' && !el.closest?.('#__awego_translate_btn__'))) {
      setTimeout(() => {
        if (document.activeElement !== activeInput) hideButton();
      }, 150);
    }
  });

  window.addEventListener('scroll', () => {
    if (activeInput) positionButton(activeInput);
  }, true);

  window.addEventListener('resize', () => {
    if (activeInput) positionButton(activeInput);
  });

  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && e.key === 'E') {
      e.preventDefault();
      if (activeInput) {
        const btn = document.getElementById('__awego_translate_btn__');
        if (btn) btn.click();
      }
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'translate' && activeInput) {
      const btn = document.getElementById('__awego_translate_btn__');
      if (btn) btn.click();
    }
  });

  createButton();
})();
