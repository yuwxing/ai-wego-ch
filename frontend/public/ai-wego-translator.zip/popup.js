const apiKeyInput = document.getElementById('apiKey');
const apiEndpointInput = document.getElementById('apiEndpoint');
const statusDiv = document.getElementById('status');

function showStatus(msg, type) {
  statusDiv.textContent = msg;
  statusDiv.className = `status ${type}`;
  setTimeout(() => { statusDiv.className = 'status'; }, 3000);
}

chrome.storage.local.get(['apiKey', 'apiEndpoint'], (result) => {
  if (result.apiKey) apiKeyInput.value = result.apiKey;
  if (result.apiEndpoint) apiEndpointInput.value = result.apiEndpoint;
});

apiKeyInput.addEventListener('change', () => {
  const val = apiKeyInput.value.trim();
  chrome.storage.local.set({ apiKey: val || '' }, () => {
    showStatus(val ? 'API Key 已保存' : 'API Key 已清除', 'success');
  });
});

apiEndpointInput.addEventListener('change', () => {
  const val = apiEndpointInput.value.trim();
  chrome.storage.local.set({ apiEndpoint: val || '' }, () => {
    showStatus(val ? 'API 地址已保存' : '已使用默认地址', 'success');
  });
});
